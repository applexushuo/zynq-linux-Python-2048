# coding=utf-8
'''python运行文件是总会出现乱码问题，为了解决这个问题，在文件开头加上的。'''
import pygame
'''是一组用来开发游戏软件的 Python 程序模块'''
from pygame.locals import *
'''将所有的 Pygame 常量导入'''
from sys import exit
'''将 exit 导入'''
import sys
'''sys 模块提供了许多函数和变量来处理 Python 运行时环境的不同部分'''
from random import *
'''将所有的 random 常量导入'''
from math import pi
'''引入 pi '''
import random
'''random —— 生成伪随机数，该模块为各种分布实现伪随机数生成器'''
background_image_filename = '20.png'		#背景图像
PIXEL = 150  								#像素
SCORE_PIXEL = 100  							#分数像素
SIZE = 4 									#大小
#定义全局变量
global scores
global max_sco
max_sco = 0									#最高分数
scores = 0									#分数
pygame.init();								#初始化所有导入的pygame模块
screen = pygame.display.set_mode((490, 650), 0, 32)	#创建一个窗口宽、高、像素
pygame.display.set_caption("Hello, World!")			#设置窗口标题
background = pygame.image.load(background_image_filename).convert()	# 加载资源图片，返回图片对象，convert()转换
Size = 4
#定义一个Button类，所有类都是object的子类
class Button(object):

	#初始化，自己的名称、颜色、位置、分数。
	def __init__(self, name, col,position, size):
		self.name = name
		self.col = col
		self.size = size
		self.position = position
	#获取鼠标的位置，返回值为元组类型（x，y）即鼠标位置的坐标。
	def isOver(self):
		point_x,point_y = pygame.mouse.get_pos()	
		x, y = self. position
		w, h = self.size
		in_x = x - w < point_x < x
		in_y = y - h < point_y < y
		return in_x and in_y
	#绘制表格
	def render(self):
		w, h = self.size
		x, y = self.position

		#绘制矩形框外表、颜色、矩形大小、宽度。
		pygame.draw.rect(screen, self.col, ((x - w, y - h), (w, h)), 0)	
		#设置字体的文字和大小。
		num_font = pygame.font.Font(None, h - 1)
		#render(名称, 开启抗锯齿, 颜色)，返回文字对象。
		font_test=num_font.render(self.name, True, (255, 255, 255))
		#获得一个对象的rect，以便于设置其坐标位置。
		fsetting = font_test.get_rect()
		fsetting.center = (x - w / 2, y - h / 2)
		# 在指定位置绘制指定文字对象。
		screen.blit(font_test,fsetting)

#返回颜色
def cal(x):
   t = -1;
   while (x > 0):
       t += 1;
       x /= 2;
   return colours[t]

#最高分数判断
def add_scores(x):
   global scores
   scores +=  x
   global max_sco
   if (scores > max_sco):
        max_sco = scores

#地图初始化
def map_init():
	
   #主区域
   screen.fill((250, 248, 239))				#填满屏幕。
   screen.blit(background, (14,25))			#图片显示区。
   submap = pygame.Surface((436, 436))		#将图片绘制到屏幕相应坐标上。
   #小块区域
   submap.fill((187, 173, 160)) 
   screen.blit(submap, (30, 185))
   block = pygame.Surface((95, 95)) 
   #返回得分
   button.name = str(scores) 
   button.render()
   #返回最分
   menu.name = str(max_sco) 
   menu.render()
   for i in range(Size):
     for j in range(Size):
        x = 30 + (i + 1) * 8 + i * 100;
        y = 185 + (j + 1) * 8 + j * 100;
        block.fill((205, 193, 180)) 		#填满小块。
        screen.blit(block, (x, y))			#绘制小块。
        if (a[i][j] == 0):					#判断a[i][j]等于0 结束if循环。
           continue
        block.fill(cal(a[i][j]))
        screen.blit(block, (x, y))
        if (a[i][j] <= 4):
			#render(名称, 开启抗锯齿, 颜色)，返回文字对象。
            font_test=num_font.render(str(a[i][j]), True, (119, 110, 101))
        else: 
			#render(名称, 开启抗锯齿, 颜色)，返回文字对象。
            font_test=num_font.render(str(a[i][j]), True, (249, 246, 242))
        fsetting = font_test.get_rect()		#设置文字矩形对象位置。
        fsetting.center = (x + 50, y + 50)	#坐标。
        screen.blit(font_test,fsetting)		#在坐标位置绘制font_test。

#更新界面
def puts(s):
   font_test=num_font.render(s	, True, (100, 100, 0))	#render(名称, 开启抗锯齿, 颜色)，返回文字对象。
   fsetting = font_test.get_rect()						#设置文字矩形对象位置。
   fsetting.center = (500, 50)							#坐标。
   screen.blit(font_test,fsetting)						#在坐标位置绘制font_test。
   pygame.display.update()								#更新界面

#数据初始化
def data_init():
   for i in range(4):
     for j in range(4):
       a[i][j] = 0;
   x1 = 0
   x2 = 0
   y1 = 0
   y2 = 0
   
   #随机生成0到3之间的整数，赋值给坐标
   while((x1 == x2 and y1 == y2)):
       x1 = random.randint(0, 3)
       x2 = random.randint(0, 3)
       y1 = random.randint(0, 3)
       y2 = random.randint(0, 3)
   #生成的数都为2
   a[x1][y1] = 2;
   a[x2][y2] = 2;

#产生随机数据
def insert():
   ran = random.randint(0, 7)		#随机生成0到7的整数
   if (ran == 0):					#随机产生8（概率极小）
       num = 8
   elif (ran <= 2):					#随机产生4（概率小）
       num = 4
   else:							#随机产生2（概率极大）
       num = 2
	   
   #随机生成0到3之间的整数，赋值给坐标
   x = random.randint(0, 3)
   y = random.randint(0, 3)
   while(a[x][y] != 0):
      x = random.randint(0, 3)
      y = random.randint(0, 3)
   a[x][y] = num

#检查列
def check_column():
  for j in range(4):
     x = 0
     for i in range (4):
         if (a[i][j] != 0 and a[i][j] == x):	#两次for循环判断列是否空位置
             return True
         else :
             x = a[i][j]
  return False 

#检查行
def check_row():
   for i in range(4):
       x = 0
       for j in range (4):
           if (a[i][j] != 0 and a[i][j] == x):	#两次for循环判断行是否空位置
               return True
           else:
               x = a[i][j]
   return False

'''上、下、左、右按键为空'''
def up_zero():
  for j in range(4):
    for i in range(1, 4):
      if (a[i][j] != 0 and a[i - 1][j] == 0):
        return True
  return False
def down_zero():
  for j in range(4):
    for i in range(0, 3):
      if (a[i][j] != 0 and a[i + 1][j] == 0):
        return True
  return False
def left_zero():
     for i in range(4):
         for j in range(1, 4):
            if (a[i][j] != 0  and a[i][j - 1] == 0):
                return True
     return False 
def right_zero():
     for i in range(4):
         for j in range(0, 3):
            if (a[i][j] != 0  and a[i][j + 1] == 0):
                return True
     return False 

#判断游戏结束之一：界面上没有空位
def has_zero():
   for i in range(4):
     for j in range(4):
        if (a[i][j] == 0) :
           return True
   return False 
#判断游戏结束之一：界面上没有可以改变的数值
def alter():
   dx = [0, 1, 0, -1]
   dy = [1, 0, -1, 0]
   for i in range(4):
      for j in range(4):
         for k in range(4):
            x = i + dx[k]
            y = j + dy[k]
            if (x >= 0 and x < 4 and y >= 0 and y <4 and a[x][y] == a[i][j]):                
               return True
   return False
#游戏结束
def game_over():
	#两个条件都为真时
   if (has_zero() == True  or alter() == True):
       return False
   return True   

'''按下上、下、左、右按键'''
def push_up():
   for j in range(4):
       bol = [0 for x in range(4)]		#创建新的列表
       i = 1;
       while(i < 4):
		  #当i>0和当前模块不为空和当前模块的上方为空三个条件同时成立时为真
          while(i > 0 and a[i][j] != 0 and a[i - 1][j] == 0):
			  #向上移位
              a[i - 1][j] =a[i][j];
              a[i][j] = 0;
              i -= 1
		  #（当i>0）和（新的序列前一位为0）和（当前模块与上面的模块相等）三个条件同时成立时执行if循环
          if (i > 0 and bol[i - 1] == 0 and a[i][j] == a[i - 1][j]):
              a[i - 1][j] *= 2; 		#上一模块数字变为当前模块数字*2
              add_scores(a[i - 1][j])	#加分
              a[i][j] = 0;				#当前模块为空
              bol[i - 1] = 1;			#新序列移动一位
          i += 1
def push_down():
  for j in range(4):
      bol = [0 for x in range(4)]
      i = 2;
      while (i >= 0):
		  #当i + 1<= 3和当前模块不为空和当前模块的下方为空三个条件同时成立时为真
          while(i + 1<= 3 and a[i][j] != 0 and a[i + 1][j] == 0):
			  #向下移位
              a[i + 1][j] = a[i][j]
              a[i][j] = 0
              i += 1
		  #（当i < 3）和（新的序列下一位为0）和（当前模块与下面的模块相等）三个条件同时成立时执行if循环
          if (i < 3 and bol[i + 1] == 0 and a[i][j] == a[i + 1][j]):
              a[i + 1][j] = a[i + 1][j] * 2	#下一模块数字变为当前模块数字*2
              add_scores( a[i + 1][j])		#加分
              a[i][j] = 0					#当前模块为空
              bol[i + 1] = 1				#新序列移动一位
          i -= 1
def push_left():
   for i in range(4):
       bol = [0 for x in range(4)]
       j = 1;
       while(j < 4):
		   #当j > 0和当前模块不为空和当前模块的左方为空三个条件同时成立时为真
           while (j > 0 and a[i][j] != 0 and a[i][j - 1] == 0):
			   #向左移位
               a[i][j - 1] = a[i][j]
               a[i][j] = 0
               j -= 1
		   #（当j > 0）和（新的序列下一位为0）和（当前模块与左面的模块相等）三个条件同时成立时执行if循环
           if (j > 0 and bol[j - 1] == 0 and a[i][j] == a[i][j - 1]):
               a[i][j - 1] *= 2				#下一模块数字变为当前模块数字*2
               add_scores(a[i][j - 1])		#加分
               a[i][j] = 0					#当前模块为空
               bol[j - 1] = 1;				#新序列移动一位
           j += 1
def push_right():
   for i in range(4):
       bol = [0 for x in range(4)]
       j = 4;
       while(j >= 0):
	       #当j < 3和当前模块不为空和当前模块的右方为空三个条件同时成立时为真
           while(j < 3 and a[i][j + 1] == 0 and a[i][j] != 0):
               a[i][j + 1] = a[i][j]
               a[i][j] = 0
               j += 1
		   #（当j < 3）和（新的序列下一位为0）和（当前模块与右面的模块相等）三个条件同时成立时执行if循环
           if (j < 3 and bol[j] == 0 and a[i][j] == a[i][j + 1]):
               a[i][j + 1] *= 2				#下一模块数字变为当前模块数字*2
               add_scores(a[i][j + 1])		#加分
               a[i][j] = 0					#当前模块为空
           j -= 1

#此方法用于绘制一个矩形框
def ply_with():
   pygame.draw.rect(screen, (0, 255, 0), ((200, 5), (100, 100)), 10)	#屏幕、颜色、形状、宽度
   pygame.draw.rect(screen, (255, 255, 0), ((310, 5), (105, 100)), 10)
   pygame.draw.rect(screen, (0, 0, 255), ((200, 115), (100, 100)), 10)

num_font = pygame.font.Font(None, 62)				#设置字体的文字和大小。
a = [[0 for col in range(4)] for row in range(4)] 	#生成一个4*4的2维数组 
colours = [(238, 228, 218), (237, 224, 200), (242, 177, 121), 
			(245, 149, 99), (245, 129, 96), (246, 94, 59), (237, 207, 114), 
			(237, 204, 97), (237, 200, 80), (255, 215, 0), (255, 140, 0)]
data_init()											#调用初始化函数
button = Button("New", (187, 173, 160),(360,87),(85, 25))
menu = Button("Menu", (187, 173, 160),(463,87),(85, 25))
tr = Button("Menu", (0, 0, 0),(469,143),(113, 37))
while True:
	# 获得所有事件的列表
    for event in pygame.event.get():
       if event.type == pygame.QUIT:		#鼠标点击关闭窗口事件
           exit()							#退出
       elif event.type ==  MOUSEBUTTONDOWN:	#鼠标点击新游戏事件
           if (tr.isOver() == True): 		#获取鼠标的位置，确定鼠标点了New Game位置。
                data_init()					#初始化
                scores = 0					#分数清零
       elif event.type == KEYDOWN:		 	#键盘按下事件
           delta = False
           if  event.key == K_LEFT:			#判断用户按下的键是否是左键
               if (check_column() == True  or  up_zero() == True):		#判断列是否有位置或者是否按下了上键
                  push_up()
                  delta = True
           elif  event.key == K_RIGHT:		#判断用户按下的键是否是右键
               if (check_column() == True  or  down_zero() == True):	#判断列是否有位置或者是否按下了下键
                  push_down()
                  delta = True
           elif  event.key == K_UP:			#判断用户按下的键是否是上键
               if (check_row() == True  or  left_zero() == True):		#判断行是否有位置或者是否按下了左键
                  push_left()
                  delta = True
           elif  event.key == K_DOWN: 		#判断用户按下的键是否是下键
               if (check_row() == True  or  right_zero() == True):		#判断行是否有位置或者是否按下了右键
                  push_right()
                  delta = True
           if (delta == True and has_zero() == True):					#判断是否按下了按键和界面是否有空位置
               insert()						#产生随机数据
           if (game_over() == True):									#game_over函数是否为真
               print "Loser"				#游戏结束
    map_init()								#更新地图
    pygame.display.update()					#更新界面